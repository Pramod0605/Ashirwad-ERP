<!DOCTYPE html>
<html dir="<?php echo ($front_setting->is_active_rtl) ? "rtl" : "ltr"; ?>" lang="<?php echo ($front_setting->is_active_rtl) ? "ar" : "en"; ?>">

<head>
    <meta charset="utf-8">
    <title><?php echo $page['title']; ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="title" content="<?php if (isset($page['meta_title'])) {echo $page['meta_title'];}?>">
    <meta name="keywords" content="<?php if (isset($page['meta_keyword'])) {echo $page['meta_keyword'];}?>">
    <meta name="description" content="<?php if (isset($page['meta_description'])) {echo $page['meta_description'];}?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo base_url($front_setting->fav_icon); ?>" type="image/x-icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo $base_url; ?>backend/themes/smooth_blue/lib/animate/animate.min.css" rel="stylesheet">
    <link href="<?php echo $base_url; ?>backend/themes/smooth_blue/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo $base_url; ?>backend/themes/smooth_blue/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?php echo $base_url; ?>backend/themes/smooth_blue/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/smooth_blue/datepicker/bootstrap-datepicker3.css"/>
    <link rel="stylesheet" href="<?php echo $base_url; ?>backend/dist/css/ss-print.css">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" style="height:125px !important">
        <a href="<?php echo $base_url; ?>views/themes/smooth_blue/layout.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <a class="navbar-brand logo" href="<?php echo base_url(); ?>"><img src="<?php echo base_url($front_setting->logo); ?>" alt=""></a>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="<?php echo $base_url; ?>views/themes/smooth_blue/layout" class="nav-item nav-link active">Home</a>
                <a href="<?php echo $base_url; ?>views/themes/smooth_blue/admission" class="nav-item nav-link">Online Admission</a>
                <a href="<?php echo $base_url; ?>views/themes/smooth_blue/examresult" class="nav-item nav-link">Exam Result</a>
                <a href="<?php echo $base_url; ?>views/themes/smooth_blue/about" class="nav-item nav-link">About Us</a>
                <a href="<?php echo $base_url; ?>views/themes/smooth_blue/layout" class="nav-item nav-link">News</a>
                <a href="<?php echo $base_url; ?>views/themes/smooth_blue/courses" class="nav-item nav-link">Gallery</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="<?php echo $base_url; ?>views/themes/smooth_blue/team.php" class="dropdown-item">Our Team</a>
                        <a href="<?php echo $base_url; ?>views/themes/smooth_blue/testimonial.php" class="dropdown-item">Testimonial</a>
                        <a href="<?php echo $base_url; ?>views/themes/smooth_blue/404.php" class="dropdown-item">404 Page</a>
                    </div>
                </div>
                <a href="<?php echo $base_url; ?>views/themes/smooth_blue/contact.php" class="nav-item nav-link">Contact</a>
            </div>
            <a href="" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block" style="line-height: 60px;">Login<i class="fa fa-arrow-right ms-3"></i></a>
        </div>
    </nav>
    <!-- Navbar End -->