 <!-- Footer Start -->
 <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Quick Link</h4>
                    <a class="btn btn-link" href="">About Us</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                    <a class="btn btn-link" href="">Privacy Policy</a>
                    <a class="btn btn-link" href="">Bus Information</a>
                    <a class="btn btn-link" href="">FAQs & Help</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Contact</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i><?php echo $school_setting->address; ?></p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i><?php echo $school_setting->phone; ?></p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i><?php echo $school_setting->email; ?></p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-outline-light btn-social" href="<?php echo $front_setting->twitter_url; ?>"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social" href="<?php echo $front_setting->fb_url; ?>"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social" href="<?php echo $front_setting->youtube_url; ?>"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href="<?php echo $front_setting->linkedin_url; ?>"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        <p><?php echo $front_setting->footer_text; ?></p>

                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="">Home</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/smooth_blue/lib/wow/wow.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/smooth_blue/lib/easing/easing.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/smooth_blue/lib/waypoints/waypoints.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/smooth_blue/lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?php echo $base_url; ?>backend/themes/smooth_blue/js/main.js"></script>
</body>

</html>