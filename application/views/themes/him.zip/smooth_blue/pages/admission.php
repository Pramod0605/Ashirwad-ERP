<?php include("header.php") ?>



        <script src="<?php echo $base_url; ?>/backend/dist/js/moment.min.js"></script>
         <!--file dropify-->
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/dist/css/dropify.min.css">
        <script src="<?php echo $base_url; ?>backend/custom/jquery.min.js"></script>
        <!--file dropify-->
        <script src="<?php echo $base_url; ?>backend/dist/js/dropify.min.js"></script>
        <script type="text/javascript">
            var base_url = "<?php echo $base_url; ?>";
        </script>
        <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>dist/css/bootstrap-select.min.css">
        <script type="text/javascript" src="<?php echo $base_url; ?>dist/js/bootstrap-select.min.js"></script>
        <script type="text/javascript">
        $(function () {
            $('.languageselectpicker').selectpicker();
        });
        </script>
            



                <div class="container spacet50">
            <div class="row">
                                <div class="col-md-12">
                    <link rel="stylesheet" href="<?php echo $base_url; ?>backend/datepicker/css/bootstrap-datetimepicker.css">
<script src="<?php echo $base_url; ?>backend/datepicker/js/bootstrap-datetimepicker.js"></script>


    <div class="row justify-content-center align-items-center flex-wrap d-flex pt20">
        <div class="col-md-6 col-lg-5 col-sm-5">
            <h3 class="entered mt0">Online Admission</h3>
        </div>
        <div class="col-md-6 col-lg-7 col-sm-7 text-lg-right">
            <a href="#checkOnlineAdmissionStatus" class="modalclosebtn modal-close-xs w-full-xs mr-lg-1" onclick="openStatusFormmodal();" data-toggle="modal" data-target="#checkOnlineAdmissionStatus">Check Your Form Status</a>
                    </div>
    </div>
   <form id="form1" class="spaceb60 spacet40 onlineform" action="<?php echo $base_url; ?>welcome/admission"  id="employeeform" name="employeeform" method="post" accept-charset="utf-8" enctype="multipart/form-data">
         <div class="printcontent">
    <div class="row">
    <h4 class="pagetitleh2">Basic Details</h4>
        <div class="col-md-3">
            <div class="form-group">
                <label>Class</label><small class="req"> *</small>
                <select  id="class_id" name="class_id" class="form-control"  >
                    <option value="">Select</option>
                                            <option value="1">Class 1</option>
                                                <option value="2">Class 2</option>
                                                <option value="3">Class 3</option>
                                                <option value="4">Class 4</option>
                                                <option value="5">Class 11th</option>
                                                <option value="6">Class 12th</option>
                                                <option value="7">Class7th</option>
                                        </select>
                <span class="text-danger"></span>
            </div>
        </div>
        <div class="col-md-3 displaynone">
            <div class="form-group">
                <label>Section</label><small class="req"> *</small>
                <select  id="section_id" name="section_id" class="form-control" >
                    <option value="">Select</option>
                </select>
                <span class="text-danger"></span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>First Name</label><small class="req"> *</small>
                <input id="firstname" name="firstname" placeholder="" type="text" class="form-control"  value="" autocomplete="off" />
                <span class="text-danger"></span>
            </div>
        </div>
                          <div class="col-md-3">
            <div class="form-group">
                <label>Last Name</label>
                <input id="lastname" name="lastname" placeholder="" type="text" class="form-control"  value="" autocomplete="off" />
                <span class="text-danger"></span>
            </div>
        </div>
            </div><!--./row-->
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Gender</label><small class="req"> *</small>
                <select class="form-control" name="gender">
                    <option value="">Select</option>
                                            <option value="Male" >Male</option>
                                                <option value="Female" >Female</option>
                                        </select>
                <span class="text-danger"></span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Date Of Birth</label><small class="req"> *</small>
                <input  type="text" class="form-control date2"  value="" id="dob" name="dob" readonly="readonly"/>
                <span class="text-danger"></span>
            </div>
        </div>
                  <div class="col-md-3">
            <div class="form-group">
                <label>Mobile Number</label>
                <input  type="text" class="form-control"  value="" id="mobileno" name="mobileno" autocomplete="off"/>
                <span class="text-danger"></span>
            </div>
        </div>
                         <div class="col-md-3">
            <div class="form-group">
                <label>Email</label><small class="req"> *</small>
                <input  type="text" class="form-control"  value="" id="email" name="email" autocomplete="off"/>
                <span class="text-danger"></span>
            </div>
        </div>
            </div><!--./row-->
    <div class="row">
                         </div><!--./row-->
    <div class="row">
                                </div><!--./row-->
    <div class="row">
            </div>
    <div class="row">
                    </div>
     </div>
             <div class="printcontent">
       <div class="row">
        <h4 class="pagetitleh2">Guardian Details</h4>
          <div class="form-group col-md-12">
            <label>If Guardian Is<small class="req"> *</small>&nbsp;&nbsp;&nbsp;</label>
            <label class="radio-inline">
                <input type="radio" name="guardian_is"    value="father"> Father            </label>
            <label class="radio-inline">
                <input type="radio" name="guardian_is"    value="mother"> Mother            </label>
            <label class="radio-inline">
                <input type="radio" name="guardian_is"    value="other"> Other            </label>
            <span class="text-danger"></span>
        </div>
                <div class="col-md-3">
            <div class="form-group">
                <label>Guardian Name</label><small class="req"> *</small>
                <input id="guardian_name" name="guardian_name" placeholder="" type="text" class="form-control"  value="" autocomplete="off" />
                <span class="text-danger"></span>
            </div>
        </div>
                           <div class="col-md-3">
            <div class="form-group">
                <label>Guardian Relation</label><small class="req"> *</small>
                <input id="guardian_relation" name="guardian_relation" placeholder="" type="text" class="form-control"  value="" autocomplete="off"/>
                <span class="text-danger"></span>
            </div>
        </div>
                         <div class="col-md-3">
            <div class="form-group">
                <label>Guardian Email</label>
                <input id="guardian_email" name="guardian_email" placeholder="" type="text" class="form-control"  value="" autocomplete="off"/>
                <span class="text-danger"></span>
            </div>
        </div>
                           <div class="col-md-3">
            <div class="form-group">
                <label>Guardian Photo</label>
                <div><input class="filestyle form-control" type='file' name='guardian_pic' id="file" size='20' />
                </div>
                <span class="text-danger"></span></div>
        </div>
            </div><!--./row-->
    <div class="row">
            <div class="col-md-3">
            <div class="form-group">
                <label>Guardian Phone</label>
                <input id="guardian_phone" name="guardian_phone" placeholder="" type="text" class="form-control"  value="" autocomplete="off"/>
                <span class="text-danger"></span>
            </div>
        </div>
                        <div class="col-md-3">
            <div class="form-group">
                <label>Guardian Occupation</label>
                <input id="guardian_occupation" name="guardian_occupation" placeholder="" type="text" class="form-control"  value="" autocomplete="off" />
                <span class="text-danger"></span>
            </div>
        </div>
                         <div class="col-md-6">
            <div class="form-group">
                <label>Guardian Address</label>
                <textarea id="guardian_address" name="guardian_address" placeholder="" class="form-control" rows="1" autocomplete="off"></textarea>
                <span class="text-danger"></span>
            </div>
        </div>
                </div>
       </div>
                                           <div class="printcontent">
          <div class="row">
            <h4 class="pagetitleh2">Upload Documents</h4>
            <div class="col-md-6">
              <div class="form-group">
                <label> Documents </label> (<small>To Upload Multiple Document Compress It In A Single File Then Upload It</small>)
                <input id="document" name="document"  type="file" class="form-control filestyle" value="" />
                <span class="text-danger"></span>
            </div>
          </div>
         </div>
        </div>
                     <div class="row">

                   
                <div class="col-lg-2 col-md-2 col-sm-5">
                    <div class="form-group  ">
                       <button type="submit" class="onlineformbtn mt10">Submit</button>
                    </div>
                </div>
                <div class="col-md-7">
                    <span class="text-danger"></span>
                </div>
            </div>
        </div><!--./row-->
</form>
<div id="checkOnlineAdmissionStatus" class="modal fade" role="dialog" tabindex="-1">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header modal-header-small">
        <button type="button" class="close closebtnmodal" data-dismiss="modal">&times;</button>
        <h4 >Check Your Form Status</h4>
      </div>
       <form action="<?php echo $base_url; ?>/welcome/checkadmissionstatus" method="post" class="onlineform" id="checkstatusform">
          <div class="modal-body">
            <div class="form-group">
            <label>Enter Your Reference Number</label><small class="req"> *</small>
               <input type="text" class="form-control" name="refno" id="refno" autocomplete="off">
                 <span class="text-danger" id="error_status_refno"></span>
            </div>
             <div class="form-group mb10">
              <label>Select Your Date of Birth</label><small class="req"> *</small>
               <input type="text"  class="form-control date2"  name="student_dob" id="student_dob" autocomplete="off" readonly="">
                <span class="text-danger" id="error_status_dob"></span>
            </div>
             <span class="text-danger" id="invaliderror"></span>
          </div>
          <div class="modal-footer">
          <button type="button" class="modalclosebtn btn  mdbtn" data-dismiss="modal">Close</button>
            <button type="submit" class="onlineformbtn mdbtn" >Submit</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
var date_format = 'mm/dd/yyyy';
var datetime_format = 'MM/DD/YYYY';

    $(document).ready(function () {
        var class_id = $('#class_id').val();
        var section_id = '0';

        getSectionByClass(class_id, section_id);

        $(document).on('change', '#class_id', function (e) {
            $('#section_id').html("");
            var class_id = $(this).val();
            getSectionByClass(class_id, 0);
        });

        $('.date2').datepicker({
            autoclose: true,
             format: date_format,
            todayHighlight: true
        });

        $('.date').datepicker({
            autoclose: true,
             format: date_format,
            todayHighlight: true
        });

        $('.datetime').datetimepicker({
         format: datetime_format + ' hh:mm a',
          locale:'en'
        });

        function getSectionByClass(class_id, section_id) {
            if (class_id !== "") {
                $('#section_id').html("");

                var div_data = '';
                var url = "";

                $.ajax({
                    type: "POST",
                    url: base_url + "welcome/getSections",
                    data: {'class_id': class_id},
                    dataType: "json",
                    beforeSend: function () {
                        $('#section_id').addClass('dropdownloading');
                    },
                    success: function (data) {
                        $.each(data, function (i, obj)
                        {
                            var sel = "";
                            if (section_id === obj.section_id) {
                                sel = "selected";
                            }
                            div_data += "<option value=" + obj.id + " " + sel + ">" + obj.section + "</option>";
                        });
                        $('#section_id').append(div_data);
                    },
                    complete: function () {
                        $('#section_id').removeClass('dropdownloading');
                    }
                });
            }
        }
    });

    function auto_fill_guardian_address() {
        if ($("#autofill_current_address").is(':checked'))
        {
            $('#current_address').val($('#guardian_address').val());
        }
    }

    function auto_fill_address() {
        if ($("#autofill_address").is(':checked'))
        {
            $('#permanent_address').val($('#current_address').val());
        }
    }

    $('input:radio[name="guardian_is"]').change(
            function () {
                if ($(this).is(':checked')) {
                    var value = $(this).val();
                    if (value === "father") {
                        var father_relation = "Father";
                        $('#guardian_name').val($('#father_name').val());
                        $('#guardian_phone').val($('#father_phone').val());
                        $('#guardian_occupation').val($('#father_occupation').val());
                        $('#guardian_relation').val(father_relation);
                    } else if (value === "mother") {
                        var mother_relation = "Mother";
                        $('#guardian_name').val($('#mother_name').val());
                        $('#guardian_phone').val($('#mother_phone').val());
                        $('#guardian_occupation').val($('#mother_occupation').val());
                        $('#guardian_relation').val(mother_relation);
                    } else {
                        $('#guardian_name').val("");
                        $('#guardian_phone').val("");
                        $('#guardian_occupation').val("");
                        $('#guardian_relation').val("");
                    }
                }
            });
</script>

<script type="text/javascript">
    function refreshCaptcha(){
        $.ajax({
            type: "POST",
            url: "<?php echo $base_url; ?>site/refreshCaptcha",
            data: {},
            success: function(captcha){
                $("#captcha_image").html(captcha);
            }
        });
    }
</script>

<script type="text/javascript">
$(document).ready(function(){
$(document).on('submit','#checkstatusform',function(e){
   e.preventDefault(); // avoid to execute the actual submit of the form.
    var form = $(this);
    var url = form.attr('action');
    var form_data = form.serializeArray();

    $.ajax({
           url: url,
           type: "POST",
           dataType:'JSON',
           data: form_data, // serializes the form's elements.
              beforeSend: function () {

               },
              success: function(response) { // your success handler
                if(response.status==0){

                    $.each(response.error, function(key, value) {

                    $('#error_status_' + key).html(value);
                    });
                }else if(response.status==2){

                    $('#error_status_dob').html("");
                    $('#error_status_refno').html("");
                    $('#invaliderror').html(response.error);
                } else{
                    var refno =response.refno ;
                    window.location.href="<?php echo $base_url; ?>welcome/online_admission_review/"+refno ;
                }
              },
             error: function() { // your error handler

             },
             complete: function() {

             }
         });
});
});
</script>

<script>
    function openStatusFormmodal(){
      $('#error_status_dob' ).html("");
      $('#error_status_refno' ).html("");
      $('#invaliderror').html("");
      $('#student_dob').val("");
      $('#student_dob').html("");
      $('#refno' ).val("");
      $(':input').val('');
    }

    function auto_fill_guardian_address() {
        if ($("#autofill_current_address").is(':checked'))
        {
            $('#current_address').val($('#guardian_address').val());
        }
    }

    function auto_fill_address() {
        if ($("#autofill_address").is(':checked'))
        {
            $('#permanent_address').val($('#current_address').val());
        }
    }
</script>

<script>
$(function(){
    $('#checkOnlineAdmissionStatus').modal({
         backdrop: 'static',
         keyboard: false,
         show: false
    });
});
</script>                </div>
                
            </div><!--./row-->
        </div><!--./container-->
        
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <h3 class="fo-title">Links</h3>
                <ul class="f1-list">
                                    </ul>
            </div><!--./col-md-3-->
            <div class="col-md-4 col-sm-6">
                <h3 class="fo-title">Follow Us</h3>
                <ul class="social">
                                    </ul>
            </div><!--./col-md-3-->
            <div class="col-md-4 col-sm-6">
                <h3 class="fo-title">Contact</h3>
                <ul class="co-list">
                    <li><i class="fa fa-envelope"></i>
                        <a href="mailto:yourschoolemail@domain.com">yourschoolemail@domain.com</a></li>
                    <li><i class="fa fa-phone"></i>Your School Phone</li>
                    <li><i class="fa fa-map-marker"></i>Your School Address</li>
                </ul>
            </div><!--./col-md-3-->
            <div class="col-md-3 col-sm-6">
                <a class="twitter-timeline" data-tweet-limit="1" href="#"></a>
            </div><!--./col-md-3-->
        </div><!--./row-->
    </div><!--./container-->

    <div class="copy-right">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 text-center">
                    <p></p>
                </div>
            </div><!--./row-->
        </div><!--./container-->
    </div><!--./copy-right-->
    <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</footer>
<script>
    function setsitecookies() {
        $.ajax({
            type: "POST",
            url: "<?php echo $base_url; ?>welcome/setsitecookies",
            data: {},
            success: function (data) {
                $('.cookieConsent').hide();
            }
        });
    }

    function check_cookie_name(name)
    {
        var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        if (match) {
            console.log(match[2]);
            $('.cookieConsent').hide();
        }
        else{
           $('.cookieConsent').show();
        }
    }
    check_cookie_name('sitecookies');
</script>        <script src="<?php echo $base_url; ?>backend/themes/default/js/bootstrap.min.js"></script>
        <script src="<?php echo $base_url; ?>backend/themes/default/js/owl.carousel.min.js"></script>
        <script type="text/javascript" src="<?php echo $base_url; ?>backend/themes/default/js/jquery.waypoints.min.js"></script>
        <script type="text/javascript" src="<?php echo $base_url; ?>backend/themes/default/js/jquery.counterup.min.js"></script>
        <script src="<?php echo $base_url; ?>backend/themes/default/js/ss-lightbox.js"></script>
        <script src="<?php echo $base_url; ?>backend/themes/default/js/custom.js"></script>
        <!-- Include Date Range Picker -->
        <script type="text/javascript" src="<?php echo $base_url; ?>themes/default/datepicker/bootstrap-datepicker.min.js"></script>
        <script type="text/javascript">
            $(function () {
                jQuery('img.svg').each(function () {
                    var $img = jQuery(this);
                    var imgID = $img.attr('id');
                    var imgClass = $img.attr('class');
                    var imgURL = $img.attr('src');

                    jQuery.get(imgURL, function (data) {
                        // Get the SVG tag, ignore the rest
                        var $svg = jQuery(data).find('svg');

                        // Add replaced image's ID to the new SVG
                        if (typeof imgID !== 'undefined') {
                            $svg = $svg.attr('id', imgID);
                        }
                        // Add replaced image's classes to the new SVG
                        if (typeof imgClass !== 'undefined') {
                            $svg = $svg.attr('class', imgClass + ' replaced-svg');
                        }

                        // Remove any invalid XML tags as per http://validator.w3.org
                        $svg = $svg.removeAttr('xmlns:a');

                        // Check if the viewport is set, else we gonna set it if we can.
                        if (!$svg.attr('viewBox') && $svg.attr('height') && $svg.attr('width')) {
                            $svg.attr('viewBox', '0 0 ' + $svg.attr('height') + ' ' + $svg.attr('width'))
                        }

                        // Replace image with new SVG
                        $img.replaceWith($svg);

                    }, 'xml');

                });
            });
            
            $(document).on('change','.currency_list',function(e){ 
                let currency_id=$(this).val();
                $.ajax({
                    type: 'POST',
                    url: base_url+'welcome/changeCurrencyFormat',
                    data: {'currency_id':currency_id},
                    dataType: 'json',
                    beforeSend: function() {
                        
                    },
                    success: function(data) {          
                        window.location.reload();
                    },
                    error: function(xhr) { // if error occured
                
                    },
                    complete: function() {
                        
                    }
                
                });
            });
        </script>
    </body>
</html>


<?php include("footer.php") ?>