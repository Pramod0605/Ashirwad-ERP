<?php include("header.php") ?>

<h1>base layout</h1>


<?php include("footer.php") ?>