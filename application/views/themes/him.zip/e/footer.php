 <!-- Footer Start -->
 <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Address</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Bangalore</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+91 12345 67890</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>scholerly@gmail.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Opening Hours</h4>
                    <h6 class="text-light">Monday - Saturday:</h6>
                    <p class="mb-4">07.00 AM - 03.00 PM</p>
                    <h6 class="text-light">Sunday - Office time:</h6>
                    <p class="mb-0">08.00 AM - 12.00 PM</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Pages</h4>
                    <a class="btn btn-link" href="">Test results</a>
                    <a class="btn btn-link" href="">Fee enquiry</a>
                    <a class="btn btn-link" href="">Onlinen admission</a>
                    <a class="btn btn-link" href="">Notices</a>
                    <a class="btn btn-link" href="">Gallery</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <img src="<?php echo base_url($front_setting->logo); ?>">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="https://scholerly.com/">scholerly</a>, All Right Reserved.
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="">Home</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/e/lib/wow/wow.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/e/lib/easing/easing.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/e/lib/waypoints/waypoints.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/e/lib/counterup/counterup.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/e/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/e/lib/tempusdominus/js/moment.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/e/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="<?php echo $base_url; ?>backend/themes/e/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?php echo $base_url; ?>backend/themes/e/js/main.js"></script>
</body>

</html>