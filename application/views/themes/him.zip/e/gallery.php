<?php include 'header.php';?>

    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="text-center">
                <h6 class="text-primary text-uppercase">// service before self //</h6>
                <h1 class="mb-5">Gallery</h1>
            </div>
            <div class="owl-carousel testimonial-carousel position-relative">
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/imageawrd.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/dps.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/cover1.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/banner.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="owl-carousel testimonial-carousel position-relative">
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/imageawrd.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/dps.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/cover1.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/banner.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
            </div>
        </div>
    </div>


    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="owl-carousel testimonial-carousel position-relative">
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/imageawrd.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/dps.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/cover1.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
                <div class="testimonial-item text-center">
                    <img class="bg-light  p-2 mx-auto mb-3" src="img/banner.jpg" style="width: 400px; height: auto;">
                    <h5 class="mb-0">Republic day</h5>
                    <p>26-01-2024</p>
                </div>
            </div>
        </div>
    </div>



<?php include 'footer.php';?>