
 
<?php include("header.php") ?>  

  <!-- ***** Main Banner Area Start ***** -->
  <section class="section main-banner" id="top" data-section="section1">
  
      <video autoplay muted loop id="bg-video">
          <source src="<?php echo $base_assets_url; ?>assets/images/course-video-short.mp4" type="video/mp4" />
      </video>

    <div class="video-overlay header-text">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="caption">
              <h6>Welcome to</h6>
              <h2>Mount Cramel School</h2>
              <p>MCS is a premier educational institution committed to fostering intellectual
                and physical growth in young minds. Our school boasts state-of-the-art infrastructure, including
                spacious classrooms, science and computer laboratories, and a
                vast playground that encourages students to maintain a healthy mind in a healthy body.
              </p>
              <div class="main-button-red">
                <div class="scroll-to-section"><a href="#contact">Contact Us</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ***** Main Banner Area End ***** -->

  <section class="services">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-service-item owl-carousel">

            <div class="item">
              <div class="icon">
                <img src="<?php echo $base_assets_url; ?>assets/images/service-icon-01.png" alt="">
              </div>
              <div class="down-content">
                <h4>Tomorrow’s Leaders</h4>
                <p>Here with us, students develop a sense of self, social skills, and independence, preparing them to take on leadership roles in the future.</p>
              </div>
            </div>

            <div class="item">
              <div class="icon">
                <img src="<?php echo $base_assets_url; ?>assets/images/service-icon-02.png" alt="">
              </div>
              <div class="down-content">
                <h4>Making a Difference</h4>
                <p>We provide a nurturing environment where students can discover their talents, and become positive change-makers in their communities.</p>
              </div>
            </div>

            <div class="item">
              <div class="icon">
                <img src="<?php echo $base_assets_url; ?>assets/images/service-icon-03.png" alt="">
              </div>
              <div class="down-content">
                <h4>Strong Bond That Lasts</h4>
                <p>We provide the most conducive environments for instilling a sense of bonding in students that extends beyond the classroom.</p>
              </div>
            </div>

            <div class="item">
              <div class="icon">
                <img src="<?php echo $base_assets_url; ?>assets/images/service-icon-02.png" alt="">
              </div>
              <div class="down-content">
                <h4>Nationally Ranked</h4>
                <p>Multiple researchers, organisations, and publications have placed our school among the best co-educational schools in India.</p>
              </div>
            </div>

            <div class="item">
              <div class="icon">
                <img src="<?php echo $base_assets_url; ?>assets/images/service-icon-03.png" alt="">
              </div>
              <div class="down-content">
                <h4>Best Networking</h4>
                <p>we offer students unparalleled networking opportunities, connecting them with industry leaders who can help them achieve their goals.</p>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="upcoming-meetings" id="news">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-heading">
            <h2>News and Events</h2>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="categories">
            <h4>Recent News</h4>
            <ul>
              <li><a href="#">Nov 10- Mentoring session with ABC</a></li>
              <li><a href="#">Nov 24- Awareness programme on mental health</a></li>
              <li><a href="#">Nov 26- Surya Namaskar Programme</a></li>
              <li><a href="#">Nov 30- Robotics Workshop </a></li>
              <li><a href="#">Dec 26- Painting Competition</a></li>
            </ul>
            <div class="main-button-red">
              <a href="meetings.html">Show all</a>
            </div>
          </div>
        </div>
        <div class="col-lg-8">
          <div class="row">
            <div class="col-lg-6">
              <div class="meeting-item">
                <div class="thumb">
                  <div class="price">
                    <span>Latest</span>
                  </div>
                  <a href="meeting-details.html"><img src="<?php echo $base_assets_url; ?>assets/images/news.jpg" alt="New Lecturer Meeting"></a>
                </div>
                <div class="down-content">
                  <div class="date">
                    <h6>Nov <span>10</span></h6>
                  </div>
                  <a href="meeting-details.html">
                    <h4>Mentoring session with ABC</h4>
                  </a>
                  <p>Students Gain Valuable Insights from Mentoring Session with ABC<br></p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="meeting-item">
                <div class="thumb">
                  <div class="price">
                    <span>Latest</span>
                  </div>
                  <a href="meeting-details.html"><img src="<?php echo $base_assets_url; ?>assets/images/news2.jpg" alt="Online Teaching"></a>
                </div>
                <div class="down-content">
                  <div class="date">
                    <h6>Nov <span>24</span></h6>
                  </div>
                  <a href="meeting-details.html">
                    <h4>Pre-board exams datesheet</h4>
                  </a>
                  <p>Pre-board Exam Datesheets Now Available:<br>Check Your Schedule</p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="meeting-item">
                <div class="thumb">
                  <div class="price">
                    <span>Latest</span>
                  </div>
                  <a href="meeting-details.html"><img src="<?php echo $base_assets_url; ?>assets/images/news3.jpg" alt="Higher Education"></a>
                </div>
                <div class="down-content">
                  <div class="date">
                    <h6>Nov <span>26</span></h6>
                  </div>
                  <a href="meeting-details.html">
                    <h4>Higher Education Conference</h4>
                  </a>
                  <p>School Attends Higher Education Conference to Explore Teaching Methods<br></p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="meeting-item">
                <div class="thumb">
                  <div class="price">
                    <span>Latest</span>
                  </div>
                  <a href="meeting-details.html"><img src="<?php echo $base_assets_url; ?>assets/images/news4.jpg" alt="Student Training"></a>
                </div>
                <div class="down-content">
                  <div class="date">
                    <h6>Nov <span>30</span></h6>
                  </div>
                  <a href="meeting-details.html">
                    <h4>Student Training Meetup</h4>
                  </a>
                  <p>School Hosts Student Training Meetup to Foster Personal and Professional Growth<br></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="apply-now" id="aboutus">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 align-self-center">
          <div class="row">
            <div class="col-lg-12">
              <div class="item">
                <h3>Online Admissions</h3>
                <p>Start your journey with us today! Apply online now.</p>
                <div class="main-button-red">
                  <div><a href="online_admission.php">Apply Now!</a></div>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="item">
                <h3>Complaint</h3>
                <p>If you have a concern, we're here to help. File a complaint.</p>
                <div class="main-button-yellow">
                  <div class="scroll-to-section"><a href="#contact">Contact Us!</a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="accordions is-first-expanded">
            <article class="accordion">
              <div class="accordion-head">
                <span>OUR MISSION</span>
                <span class="icon">
                  <i class="icon fa fa-chevron-right"></i>
                </span>
              </div>
              <div class="accordion-body">
                <div class="content">
                  <p>We will inspire and challenge every student to flourish and achieve their full potential, both now and in the future, and instill a passion for lifelong learning.</p>
                </div>
              </div>
            </article>
            <article class="accordion">
              <div class="accordion-head">
                <span>OUR VISION</span>
                <span class="icon">
                  <i class="icon fa fa-chevron-right"></i>
                </span>
              </div>
              <div class="accordion-body">
                <div class="content">
                  <p>MCS strives to be a globally leading innovative international school that fosters a culture of aspiration, empowerment and strong community values - making it the first school of choice.</p>
                </div>
              </div>
            </article>
            <article class="accordion">
              <div class="accordion-head">
                <span>Why Choose Our Institution?</span>
                <span class="icon">
                  <i class="icon fa fa-chevron-right"></i>
                </span>
              </div>
              <div class="accordion-body">
                <div class="content">
                  <p>Choosing our institution means joining a community of learners who are passionate about making a positive impact. Our students benefit from a supportive environment that encourages creativity, critical thinking, and collaboration. With a strong emphasis on practical learning and real-world experiences, our graduates leave well-prepared to succeed in their chosen fields.</p>
                </div>
              </div>
            </article>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="our-courses" id="events">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-heading">
            <h2>Our Staff</h2>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="owl-courses-item owl-carousel">
            <div class="item">
              <img src="<?php echo $base_assets_url; ?>assets/images/teacher1.jpg" alt="Course One">
              <div class="down-content">
                <h4>Saakshi Sankaran<br>Contact</br></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <ul>
                        <li>English Teacher</li>
                      </ul>
                    </div>
                    <div class="col-4">
                      <span>5th</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <img src="<?php echo $base_assets_url; ?>assets/images/teacher2.png" alt="Course Two">
              <div class="down-content">
                <h4>Radha Apte<br>Contact</br></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <ul>
                        <li>English Teacher</li>
                      </ul>
                    </div>
                    <div class="col-4">
                      <span>11th Com</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <img src="<?php echo $base_assets_url; ?>assets/images/teacher3.jpg" alt="">
              <div class="down-content">
                <h4>Harish Mitter<br>Contact</br></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <ul>
                        <li>English Teacher</li>
                      </ul>
                    </div>
                    <div class="col-4">
                      <span>11th Com</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <img src="<?php echo $base_assets_url; ?>assets/images/teacher4.jpg" alt="">
              <div class="down-content">
                <h4>Mohini Nanda<br>Contact</br></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <ul>
                        <li>PE Teacher</li>
                      </ul>
                    </div>
                    <div class="col-4">
                      <span>10th</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <img src="<?php echo $base_assets_url; ?>assets/images/teacher1.jpg" alt="">
              <div class="down-content">
                <h4>Rajani Manda<br>Contact</br></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <ul>
                        <li>Math Teacher</li>
                      </ul>
                    </div>
                    <div class="col-4">
                      <span>9th</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <img src="<?php echo $base_assets_url; ?>assets/images/teacher3.jpg" alt="">
              <div class="down-content">
                <h4>Harish Mitter<br>Contact</br></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <ul>
                         <li>English Teacher</li>
                      </ul>
                    </div>
                    <div class="col-4">
                      <span>12th Sci</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <img src="<?php echo $base_assets_url; ?>assets/images/teacher4.jpg" alt="">
              <div class="down-content">
                <h4>Nitya Seth<br>Contact</br></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <ul>
                        <li>English Teacher</li>
                      </ul>
                    </div>
                    <div class="col-4">
                      <span>7th</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <img src="<?php echo $base_assets_url; ?>assets/images/teacher1.jpg" alt="">
              <div class="down-content">
                <h4>Anala Menon<br>Contact</br></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <ul>
                        <li>Science Teacher</li>
                      </ul>
                    </div>
                    <div class="col-4">
                      <span>8th</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="our-facts">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="row">
            <div class="col-lg-12">
              <h2>Achievements</h2>
            </div>
            <div class="col-lg-6">
              <div class="row">
                <div class="col-12">
                  <div class="count-area-content percentage">
                    <div class="count-digit">94</div>
                    <div class="count-title">Succesed Students</div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="count-area-content">
                    <div class="count-digit">126</div>
                    <div class="count-title">Current Teachers</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="row">
                <div class="col-12">
                  <div class="count-area-content new-students">
                    <div class="count-digit">2345</div>
                    <div class="count-title">New Students</div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="count-area-content">
                    <div class="count-digit">32</div>
                    <div class="count-title">Awards</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6 align-self-center">
          <div class="video">
            <a href="https://www.youtube.com/watch?v=LhjGAqUsO0g" target="_blank"><img src="<?php echo $base_assets_url; ?>assets/images/play-icon.png"
                alt=""></a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="contact-us" id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-9 align-self-center">
          <div class="row">
            <div class="col-lg-12">
              <form id="contact" action="" method="post">
                <div class="row">
                  <div class="col-lg-12">
                    <h2>Let's get in touch</h2>
                  </div>
                  <div class="col-lg-4">
                    <fieldset>
                      <input name="name" type="text" id="name" placeholder="YOURNAME...*" required="">
                    </fieldset>
                  </div>
                  <div class="col-lg-4">
                    <fieldset>
                      <input name="email" type="text" id="email" pattern="[^ @]*@[^ @]*" placeholder="YOUR EMAIL..."
                        required="">
                    </fieldset>
                  </div>
                  <div class="col-lg-4">
                    <fieldset>
                      <input name="subject" type="text" id="subject" placeholder="SUBJECT...*" required="">
                    </fieldset>
                  </div>
                  <div class="col-lg-12">
                    <fieldset>
                      <textarea name="message" type="text" class="form-control" id="message"
                        placeholder="YOUR MESSAGE..." required=""></textarea>
                    </fieldset>
                  </div>
                  <div class="col-lg-12">
                    <fieldset>
                      <button type="submit" id="form-submit" class="button">SEND MESSAGE NOW</button>
                    </fieldset>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="right-info">
            <ul>
              <li>
                <h6>Phone Number</h6>
                <span><?php echo $school_setting->phone; ?></span>
              </li>
              <li>
                <h6>Email Address</h6>
                <span>scholerly@gmail.com</span>
              </li>
              <li>
                <h6>Address</h6>
                <span><?php echo $school_setting->address; ?></span>
              </li>
              <li>
                <h6>Youtube</h6>
                <span><?php echo $front_setting->youtube_url; ?></span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <?php include("footer.php") ?>
    