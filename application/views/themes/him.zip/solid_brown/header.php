<!DOCTYPE html>
<html dir="<?php echo ($front_setting->is_active_rtl) ? "rtl" : "ltr"; ?>" lang="<?php echo ($front_setting->is_active_rtl) ? "ar" : "en"; ?>">

<head>

    <title><?php echo $page['title']; ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="title" content="<?php if (isset($page['meta_title'])) {echo $page['meta_title'];}?>">
    <meta name="keywords" content="<?php if (isset($page['meta_keyword'])) {echo $page['meta_keyword'];}?>">
    <meta name="description" content="<?php if (isset($page['meta_description'])) {echo $page['meta_description'];}?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">

  <link rel="shortcut icon" href="<?php echo base_url($front_setting->fav_icon); ?>" type="image/x-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo $base_assets_url; ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


  <!-- Additional CSS Files -->
  <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/solid_brown/assets/css/fontawesome.css">
  <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/solid_brown/assets/css/templatemo-edu-meeting.css">
  <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/solid_brown/assets/css/owl.css">
  <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/solid_brown/assets/css/lightbox.css">
  <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/solid_brown/datepicker/bootstrap-datepicker3.css"/>
  <link rel="stylesheet" href="<?php echo $base_url; ?>backend/dist/css/ss-print.css">


</head>

<body>
<div class="sub-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-sm-8">
          <div class="left-content">
          <p><a class="fa fa-phone"> <a href="phoneto:<?php echo $school_setting->phone; ?>"><?php echo $school_setting->phone; ?></a>
          </div>
        </div>
        <div class="col-lg-4 col-sm-4">
          <div class="right-icons">
            <ul>
              <li style="color:white;">Follow Us</li>
              <li><a href="<?php echo $front_setting->whatsapp_url; ?>"><i class="fa fa-whatsapp"></i></a></li>
              <li><a href="<?php echo $front_setting->fb_url; ?>"><i class="fa fa-facebook"></i></a></li>
              <li><a href="<?php echo $front_setting->twitter_url; ?>"><i class="fa fa-twitter"></i></a></li>
              <li><a href="<?php echo $front_setting->linkedin_url; ?>"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="<?php echo $front_setting->youtube_url; ?>"><i class="fa fa-youtube"></i></a></li>
              <li><a href="<?php echo $front_setting->instagram_url; ?>"><i class="fa fa-instagram"></i></a></li>
              <li><a href="<?php echo $front_setting->pinterest_url; ?>"><i class="fa fa-pinterest"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky" style="height:120px !important">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="layout.php" class="logo">
            <a class="navbar-brand logo" href="<?php echo base_url(); ?>"><img src="<?php echo base_url($front_setting->logo); ?>" alt=""></a>
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li><a href="layout.php" class="active">Home</a></li>
              <li><a href="online_admission.php">Online Admission</a></li>
              <li><a href="exam_result.php">Exam Result</a></li>
              <li><a href="gallery.php">Gallery</a></li>
              <li><a href="layout.php#news">News</a></li>
              <li><a href="layout.php#aboutus">About Us</a></li>
              <li><a href="layout.php#contact">Contact Us</a></li>
              <li class="has-sub">
                <a href="javascript:void(0)">Login</a>
                <ul class="sub-menu">
                  <li><a href="admin login/login.html">Admin Login</a></li>
                  <li><a href="admin login/login.html">Student/Parent Login</a></li>
                </ul>
              </li>
            </ul>
            <a class='menu-trigger'>
              <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>