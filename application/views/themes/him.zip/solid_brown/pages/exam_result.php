
  <!-- Sub Header -->
  <?php include("header.php") ?>
  <!-- ***** Header Area End ***** -->


  <section class="heading-page header-text" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h2>Exam Result</h2>
        </div>
      </div>
    </div>
  </section>

<style>
body {
  background-image: url('assets/images/meetings-page-bg.jpg');
}
</style>


 
  <?php include("footer.php") ?>