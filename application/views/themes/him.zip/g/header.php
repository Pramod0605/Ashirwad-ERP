<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="Site keywords here">
		<meta name="description" content="">
		<meta name='copyright' content=''>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Title -->
        <title>Home</title>
		
		<!-- Favicon -->
        <link rel="icon" href="<?php echo $base_url; ?>backend/themes/g/img/favicon.png">
		
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/bootstrap.min.css">
		<!-- Nice Select CSS -->
		<link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/nice-select.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/font-awesome.min.css">
		<!-- icofont CSS -->
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/icofont.css">
		<!-- Slicknav -->
		<link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/slicknav.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/owl-carousel.css">
		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/datepicker.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/animate.min.css">
		<!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/magnific-popup.css">
		
		<!-- Medipro CSS -->
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/normalize.css">
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/style.css">
        <link rel="stylesheet" href="<?php echo $base_url; ?>backend/themes/g/css/responsive.css">
		
    </head>
    <body>
	
		<!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>

                <div class="indicator"> 
                    <svg width="16px" height="12px">
                        <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                        <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    </svg>
                </div>
            </div>
        </div>
        <!-- End Preloader -->
		
		<!-- Get Pro Button -->
		<ul class="pro-features">
			<a class="get-pro" href="#">Login</a>
			<li class="big-title">User Login</li>
			<li class="title">Admin Login</li>
			<div class="button">
				<a href="#" target="_blank" class="btn">User Login</a>
				<a href="#" target="_blank" class="btn">Admin Login</a>
			</div>
		</ul>
	
		<!-- Header Area -->
		<header class="header" >
			<!-- Topbar -->
			<div class="topbar">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 col-md-5 col-12">
							<!-- Contact -->
							<ul class="top-link">
								<li><a href="#">About</a></li>
								<li><a href="#">Teachers</a></li>
								<li><a href="#">Contact</a></li>
								<li><a href="#">FAQ</a></li>
							</ul>
							<!-- End Contact -->
						</div>
						<div class="col-lg-6 col-md-7 col-12">
							<!-- Top Contact -->
							<ul class="top-contact">
								<li><i class="fa fa-phone"></i>+880 1234 56789</li>
								<li><i class="fa fa-envelope"></i><a href="mailto:support@yourmail.com">scholerly@gmail.com</a></li>
							</ul>
							<!-- End Top Contact -->
						</div>
					</div>
				</div>
			</div>
			<!-- End Topbar -->
			<!-- Header Inner -->
			<div class="header-inner">
				<div class="container">
					<div class="inner">
						<div class="row">
							<div class="col-lg-3 col-md-3 col-12">
								<!-- Start Logo -->
								<div class="logo">
									<a href="layout.php"><img src="<?php echo base_url($front_setting->logo); ?>"></a>
								</div>
								<!-- End Logo -->
								<!-- Mobile Nav -->
								<div class="mobile-nav"></div>
								<!-- End Mobile Nav -->
							</div>
							<div class="col-lg-7 col-md-9 col-12">
								<!-- Main Menu -->
								<div class="main-menu">
									<nav class="navigation">
										<ul class="nav menu">
											<li class="active"><a href="#">Home <i class="icofont-rounded-down"></i></a>
												<ul class="dropdown">
													<li><a href="layout.php">Home Page 1</a></li>
												</ul>
											</li>
											<li><a href="#">Teachers </a></li>
											<li><a href="#">Services </a></li>
											<li><a href="#">Pages <i class="icofont-rounded-down"></i></a>
												<ul class="dropdown">
													<li><a href="404.php">404 Error</a></li>
												</ul>
											</li>
											<li><a href="#">Notice <i class="icofont-rounded-down"></i></a>
												<ul class="dropdown">
													<li><a href="blog-single.php">Blog Details</a></li>
												</ul>
											</li>
											<li><a href="contact.php">Contact Us</a></li>
										</ul>
									</nav>
								</div>
								<!--/ End Main Menu -->
							</div>
							<div class="col-lg-2 col-12">
								<div class="get-quote">
									<a href="#" class="btn">Login</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Header Inner -->
		</header>
		<!-- End Header Area -->