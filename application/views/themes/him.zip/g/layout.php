<?php include 'header.php';?>
		
		<!-- Slider Area -->
		<section class="slider">
			<div class="hero-slider">
				<!-- Start Single Slider -->
				<div class="single-slider" style="background-image:url('<?php echo $base_url; ?>backend/themes/g/img/cover1.jpg')">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="text">
									<h1 style="font-color: #FFFFFF"><FONT COLOR="#ffffff"> <strong>Mount Cramel School</strong></FONT></h1>
									<p><FONT COLOR="#ffffff">Mount Cramel strives to be a globally leading innovative international school that fosters a culture of aspiration, empowerment and strong community values - making it the first school of choice.</FONT></p>
									<div class="button">
										<a href="#" class="btn">Get in touch</a>
										<a href="#" class="btn primary">Apply now</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- End Single Slider -->
			
				<!-- Start Single Slider -->
				<div class="single-slider" style="background-image:url('<?php echo $base_url; ?>backend/themes/g/img/dps.jpg')">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="text">
								    <h1 style="font-color: #FFFFFF"><FONT COLOR="#ffffff"> <strong>Mount Cramel School</strong></FONT></h1>
									<p><FONT COLOR="#ffffff">Mount Cramel strives to be a globally leading innovative international school that fosters a culture of aspiration, empowerment and strong community values - making it the first school of choice.</FONT></p>
									<div class="button">
										<a href="#" class="btn">Get in touch</a>
										<a href="#" class="btn primary">Apply now</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- End Single Slider -->
			</div>
		</section>
		<!--/ End Slider Area -->
		
		<!-- Start Schedule Area -->
		<section class="schedule">
			<div class="container">
				<div class="schedule-inner">
					<div class="row">
						<div class="col-lg-4 col-md-6 col-12 ">
							<!-- single-schedule -->
							<div class="single-schedule first">
								<div class="inner">
									<div class="icon">
										<i class="fa fa-ambulance"></i>
									</div>
									<div class="single-content">
										<span></span>
										<h4>Tomorrow’s Leaders</h4>
										<p>Here with us, students develop a sense of self, social skills, and independence, preparing them to take on leadership roles in the future.</p>
										<a href="#">LEARN MORE<i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-12">
							<!-- single-schedule -->
							<div class="single-schedule middle">
								<div class="inner">
									<div class="icon">
										<i class="icofont-prescription"></i>
									</div>
									<div class="single-content">
										<span></span>
										<h4>Making a Difference</h4>
										<p>We assist students in recognising their individuality and learning how to stand out from the crowd, all while pursuing excellence and inspiring others.</p>
										<a href="#">LEARN MORE<i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-12 col-12">
							<!-- single-schedule -->
							<div class="single-schedule last">
								<div class="inner">
									<div class="icon">
										<i class="icofont-ui-clock"></i>
									</div>
									<div class="single-content">
										<span></span>
										<h4>Nationally Ranked</h4>
										<p>We assist students in recognising their individuality and learning how to stand out from the crowd, all while pursuing excellence and inspiring others.</p>
										<a href="#">LEARN MORE<i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/End Start schedule Area -->

		<!-- Start Feautes -->
		<section class="Feautes section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>#1 Choice for parents</h2>
							
							<p>Our values</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4 col-12">
						<!-- Start Single features -->
						<div class="single-features">
							<div class="signle-icon">
								<i class="icofont icofont-people"></i>
							</div>
							<h3>Trust</h3>
							<p>Lorem ipsum sit, consectetur adipiscing elit. Maecenas mi quam vulputate.</p>
						</div>
						<!-- End Single features -->
					</div>
					<div class="col-lg-4 col-12">
						<!-- Start Single features -->
						<div class="single-features">
							<div class="signle-icon">
								<i class="icofont icofont-thumbs-up"></i>
							</div>
							<h3>Acceptance</h3>
							<p>Lorem ipsum sit, consectetur adipiscing elit. Maecenas mi quam vulputate.</p>
						</div>
						<!-- End Single features -->
					</div>
					<div class="col-lg-4 col-12">
						<!-- Start Single features -->
						<div class="single-features last">
							<div class="signle-icon">
								<i class="icofont icofont-heart"></i>
							</div>
							<h3>Honesty</h3>
							<p>Lorem ipsum sit, consectetur adipiscing elit. Maecenas mi quam vulputate.</p>
						</div>
						<!-- End Single features -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Feautes -->
		
		<!-- Start Fun-facts -->
		<div id="fun-facts" class="fun-facts section overlay">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Fun -->
						<div class="single-fun">
							<i class="icofont icofont-people"></i>
							<div class="content">
								<span class="counter">3468</span>
								<p>Students</p>
							</div>
						</div>
						<!-- End Single Fun -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Fun -->
						<div class="single-fun">
							<i class="icofont icofont-user-alt-3"></i>
							<div class="content">
								<span class="counter">160</span>
								<p>Teachers</p>
							</div>
						</div>
						<!-- End Single Fun -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Fun -->
						<div class="single-fun">
							<i class="icofont-sand-clock"></i>
							<div class="content">
								<span class="counter">15</span>
								<p>Years of experience</p>
							</div>
						</div>
						<!-- End Single Fun -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Fun -->
						<div class="single-fun">
							<i class="icofont icofont-table"></i>
							<div class="content">
								<span class="counter">7</span>
								<p>Successful batches</p>
							</div>
						</div>
						<!-- End Single Fun -->
					</div>
				</div>
			</div>
		</div>
		<!--/ End Fun-facts -->
		
		<!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>OUR MISSION</h2>
							<img src="<?php echo $base_url; ?>backend/themes/g/img/section-img.png" alt="#">
							<p>We will inspire and challenge every student to flourish and achieve their full potential, both now and in the future, and instill a passion for lifelong learning.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>OUR VISION</h3>
							<p>MCS strives to be a globally leading innovative international school that fosters a culture of aspiration, empowerment and strong community values - making it the first school of choice. </p>
							
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->
		
		
		
		<?php include 'footer.php';?>